<!DOCTYPE html>
<html>
	
<head>
	<title>My Bus Schedule</title>
	<style>
	table {
		border-collapse: collapse;
		width: 100%;
		margin: 20px 0;
		font-size: 1em;
		min-width: 400px;
		box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
		height: 50vh; 
	}
	th, td {
		padding: 12px 15px;
	}
	thead tr {
		background-color: #009879;
		color: #ffffff;
		text-align: left;
	}
	tr:nth-of-type(even) {
		background-color: #f3f3f3;
	}
	tr:hover {
		background-color: #dddddd;
	}
	</style>
	<script>

var transitCheckpoints = [
			"HIT",
			"TOWN",
			"CHOPPIES",
			"COPPA CABANA"
		];

		function updateTransitStatus1() {
			var bus2TransitStatus = document.getElementById("bus2TransitStatus1");
			var currentStatus = bus2TransitStatus.innerHTML;
			var newStatus = currentStatus;
			while (newStatus == currentStatus) {
				newStatus = transitCheckpoints[Math.floor(Math.random() * transitCheckpoints.length)];
			}
			bus2TransitStatus.innerHTML = newStatus;
		}

		setInterval(updateTransitStatus1, 10000);


		var transitStatuses = [
			"In Transit to Coppa Cabbana",
			"In Transit to Hit",
			"Hit Rank",
			"Coppa Cabbana"
		];

		function updateTransitStatus() {
			var bus2TransitStatus = document.getElementById("bus2TransitStatus");
			var currentStatus = bus2TransitStatus.innerHTML;
			var newStatus = currentStatus;
			while (newStatus == currentStatus) {
				newStatus = transitStatuses[Math.floor(Math.random() * transitStatuses.length)];
			}
			bus2TransitStatus.innerHTML = newStatus;
		}

		setInterval(updateTransitStatus, 5000);
	</script>
</head>
<body>
	<table>
		<thead>
			<tr>
				<th>Bus Route</th>
				<th>Bus ID</th>
				<th>Checkpoints</th>
				<th>Transit Status</th>
				<th>Departure Time</th>
				<th>Price</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td rowspan="2">Route 1</td>
				<td>BUS1</td>
				<td>Hit</td>
				<td>Coppa Cabbana</td>
				<td>8:00am</td>
				<td>$5</td>
			</tr>
			<tr>
			<td>BUS2</td>
				<td id="bus2TransitStatus1">Zupco</td>
				<td id="bus2TransitStatus">In Transit to Coppa Cabbana</td>
				<td>9:30am</td>
				<td>$4</td>
			</tr>
			
			<tr>
			
				<td>Route 2</td>
				<td>BUS3</td>
				<td>Town</td>
				<td>Arrived</td>
				<td>10:00am</td>
				<td>$6</td>
			</tr>
	
		</tbody>
	</table>
</body>
</html>
